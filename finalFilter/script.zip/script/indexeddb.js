//console.log(cafe[0].cafeName);
var myJSON = JSON.stringify(cafe);
//console.log(myJSON)

var data = JSON.parse(myJSON);
//console.log(data);

/*window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;
 
window.IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction || window.msIDBTransaction;
window.IDBKeyRange = window.IDBKeyRange || window.webkitIDBKeyRange || window.msIDBKeyRange
 
if (!window.indexedDB) {
    window.alert("Your browser doesn't support a stable version of IndexedDB.")
}

var db;
var request = window.indexedDB.open("database", 1);

request.onerror = function(event) {
  console.log("Error opening the database");
};

request.onsuccess = function(event) {
  console.log("Successfully opened the database");
};

request.onupgradeneeded = function(event) {
        var db = event.target.result;
        var objectStore = dbb.createObjectStore("cafeList", {keyPath: "id"});
        for (var i in data) {
                objectStore.add(data[i]);   
        }
}

var print = function(){
    var objectStore = db.transaction("cafeList").objectStore("cafeList");
    objectStore.openCursor().onsuccess = function(event) {
    var cursor = event.target.result;
    if(cursor){
        console.log(cursor.value.cafeName);
        cursor.continue();
    }
    };
}*/

var printCafe = function(){
    console.log("hello");
   for(var i = 0; i < data.length; i++){
       var parent = document.getElementById("cafe");
       var div = document.createElement('div');
       div.setAttribute('data-cafe', data[i].cafeID)
       var img = document.createElement('img');
       img.setAttribute("src", data[i].image);
       var h1 = document.createElement('h1');
       var name = document.createTextNode(data[i].cafeName);
       h1.appendChild(name);
       var h2 = document.createElement('h2');
       var address = document.createTextNode(data[i].cafeLocation);
       h2.appendChild(address);
       div.appendChild(img);
       div.appendChild(h1);
       div.appendChild(h2);
       parent.appendChild(div);
   } 
}

window.onload = printCafe;