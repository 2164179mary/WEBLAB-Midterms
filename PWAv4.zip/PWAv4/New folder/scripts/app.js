/**
 *Events Listener 
**/
 document.getElementById("button").onclick = function () {
                    location.href="home.html";
 }
 
 
 
 