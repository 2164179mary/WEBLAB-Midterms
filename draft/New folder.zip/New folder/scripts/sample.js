document.getElementById("sample").innerHTML = menuList[1];
/*var createMenu = function(){
    var length = 10;
    while(length != 0){
        var para = document.createElement("p");
        var node = document.createTextNode("random");
        para.appendChild(node);
        var element = document.getElementById("menuResult");
        element.appendChild(para);
        length--;
    }
}*/